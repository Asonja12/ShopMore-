//Example below is the simplified process for the logic

// const createUser = async (req, res) => {
//   try {
//     res.send("create User successfully");
//   } catch (error) {
//     console.log("error creating the User in our database", error.message);
//     res.status(500).json({ message: "server", error: error.message });
//   }
// };

// export { createUser };

//Holds the business logic here

import User from "../model/user.js";

const createUser = async (req, res) => {
  try {
    const { firstName, lastName, email, phoneNumber, address, password } =
      req.body;

    //Basic Validations
    if (
      !firstName ||
      !lastName ||
      !email ||
      !phoneNumber ||
      !address ||
      !password
    ) {
      return res.status(404).json({ message: "All fields are required" });
    }

    //Create a new User Object
    const newUser = new User({
      firstName,
      lastName,
      email,
      phoneNumber,
      address,
      password,
    });

    // Save the product to database
    const savedUser = await newUser.save();

    res
      .status(201)
      .json({ message: "User Created Successfully", User: savedUser });
  } catch (error) {
    console.log("error creating the user in our database", error.message);
    res.status(500).json({ message: "server", error: error.message });
  }
};

export { createUser };
