import Product from "../model/product.js";

const createProduct = async (req, res) => {
  try {
    const {
      productTitle,
      brand,
      price,
      salesPrice,
      description,
      stock,
      image,
    } = req.body;

    //Basic Validations
    if (
      !productTitle ||
      !brand ||
      !price ||
      !salesPrice ||
      !description ||
      !stock ||
      !image
    ) {
      return res.status(404).json({ message: "All fields are required" });
    }

    //Create a new Product Object
    const newProduct = new Product({
      productTitle,
      brand,
      price,
      salesPrice,
      description,
      stock,
      image,
    });

    // Save the product to database
    const savedProduct = await newProduct.save();

    res
    .status(201)
    .json({ message: "Product Created Successfully", product: savedProduct });
  } catch (error) {
    console.log("error creating the product in our database", error.message);
    res.status(500).json({ message: "server", error: error.message });
  }
};

export { createProduct };

